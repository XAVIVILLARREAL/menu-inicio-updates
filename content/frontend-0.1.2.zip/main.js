const { invoke } = window.__TAURI__.core;
const { convertFileSrc } = window.__TAURI__.core;

const state = {
  config: null,
  connectionId: "",
  videos: [],
  currentSection: null,
  lastView: "dashboard",
};

// ───────────── NAVEGACIÓN DE VISTAS ─────────────
const VIEWS = ["dashboard", "support", "generic", "videos", "error"];

function showView(name) {
  VIEWS.forEach((v) => {
    document.getElementById(`view-${v}`).classList.toggle("active", v === name);
  });
}

function setActiveMenu(id) {
  document.querySelectorAll(".menu-item").forEach((el) => {
    el.classList.toggle("active", el.dataset.id === id);
  });
}

async function goDashboard() {
  showView("dashboard");
  setActiveMenu("dashboard");
  await refreshDashboard();
}

async function goSupport() {
  showView("support");
  setActiveMenu("soporte");
  try {
    const info = await invoke("get_system_info");
    document.getElementById("support-info").textContent =
      `ID de Conexión: ${info.connectionId}\n` +
      `Equipo: ${info.computerName}\n` +
      `Usuario: ${info.userName}\n` +
      `Sistema: ${info.osVersion}`;
  } catch (e) {
    document.getElementById("support-info").textContent = `Error: ${e}`;
  }
}

function goGeneric(section) {
  showView("generic");
  setActiveMenu(section.id);
  document.getElementById("generic-icon").textContent = section.icon;
  document.getElementById("generic-title").textContent = `${section.icon} ${section.title}`;
  document.getElementById("generic-message").textContent =
    "Para ingresar a esta información es necesario conectarse a internet. No actualice ni utilice programas de diagnóstico mientras está conectado a internet. De preferencia solo para usar esa base de datos es necesario que lea el manual de uso del equipo y la garantía.";
  window.__currentGenericSection = section;
}

async function goVideos() {
  showView("videos");
  setActiveMenu("videos");
  await loadVideoList();
}

function showError(msg) {
  document.getElementById("error-message").textContent = msg;
  showView("error");
}

// ───────────── MENÚ ─────────────
function renderMenu() {
  const container = document.getElementById("menu-sections");
  container.innerHTML = "";

  state.config.sections.forEach((section) => {
    const btn = document.createElement("button");
    btn.className = `menu-item${section.type === "url" && section.id === "chatbot" ? " ai" : ""}`;
    btn.dataset.id = section.id;
    btn.innerHTML = `<span class="icon">${section.icon}</span><span>${section.title}</span>`;

    btn.addEventListener("click", () => onSectionClick(section));
    container.appendChild(btn);
  });
}

async function onSectionClick(section) {
  switch (section.type) {
    case "dashboard":
      await goDashboard();
      break;
    case "support":
      await goSupport();
      break;
    case "videos":
      await goVideos();
      break;
    case "dir":
      await openAnalysisDir(section);
      break;
    case "url":
    default:
      goGeneric(section);
      break;
  }
}

// ───────────── DASHBOARD ─────────────
async function refreshDashboard() {
  try {
    const connId = await invoke("get_connection_id");
    state.connectionId = connId;
    document.getElementById("connection-id").textContent = connId;

    const internet = await invoke("check_internet");
    updateStatusDot(internet);
  } catch (e) {
    document.getElementById("connection-id").textContent = "ERROR";
  }

  try {
    const name = await getComputerName();
    document.getElementById("quick-system-name").textContent = name;
  } catch (_) {}

  await renderCarousel();
}

function updateStatusDot(online) {
  const el = document.querySelector(".status-active .dot");
  const label = document.querySelector(".status-active");
  if (online) {
    el.classList.remove("green", "red");
    el.classList.add("green");
    label.childNodes[2].textContent = " CONECTADO A INTERNET";
  } else {
    el.classList.remove("green", "red");
    el.classList.add("red");
    label.childNodes[2].textContent = " MODO OFFLINE";
  }
}

function getComputerName() {
  return invoke("get_system_info").then((i) => i.computerName);
}

// ───────────── TEMAS ─────────────
function renderThemeButtons() {
  const container = document.getElementById("theme-buttons");
  const temas = state.config?.paths?.temas || [];
  container.innerHTML = "";
  temas.forEach((path, i) => {
    const btn = document.createElement("button");
    btn.className = "theme-btn";
    btn.textContent = `⚡ Tema ${i + 1}`;
    btn.title = path;
    btn.addEventListener("click", withLoading(btn, () => invoke("launch", { path }).catch(showError)));
    container.appendChild(btn);
  });
}

// ───────────── CARRUSEL DE VIDEOS ─────────────
// Guard contra renders concurrentes: si `goDashboard`/`refreshDashboard` se
// llaman dos veces seguidas (arranque + click del usuario), solo la llamada
// más reciente pinta el carrusel (evita duplicados).
let carouselRenderSeq = 0;
async function renderCarousel() {
  const seq = ++carouselRenderSeq;
  const carousel = document.getElementById("video-carousel");
  carousel.innerHTML = "";

  const videos = await invoke("list_videos").catch(() => []);
  if (seq !== carouselRenderSeq) return; // otra renderización más nueva está en curso
  const preview = videos.slice(0, 6);

  preview.forEach((video) => {
    const thumb = document.createElement("div");
    thumb.className = "video-thumb";
    thumb.innerHTML = `
      <span class="play">▶</span>
      <span class="title">${escapeHtml(video.title)}</span>`;
    thumb.addEventListener("click", () => {
      goVideos().then(() => playVideo(video));
    });
    carousel.appendChild(thumb);
  });

  if (preview.length === 0) {
    const empty = document.createElement("div");
    empty.className = "video-thumb";
    empty.innerHTML = `<span class="play">🎬</span><span class="title">Sin videos</span>`;
    carousel.appendChild(empty);
  }
}

// ───────────── VIDEOS ─────────────
async function loadVideoList() {
  state.videos = await invoke("list_videos").catch(() => []);
  const container = document.getElementById("video-list");
  const count = document.getElementById("video-count");
  container.innerHTML = "";

  count.textContent = `${state.videos.length} VIDEOS`;

  if (state.videos.length === 0) {
    container.innerHTML = `<p class="card-label">No se encontraron videos. Agrega videos a la carpeta 'Videos/Tutoriales' junto al ejecutable.</p>`;
    return;
  }

  state.videos.forEach((video) => {
    const item = document.createElement("div");
    item.className = "video-item";
    item.dataset.path = video.filePath;
    item.innerHTML = `
      <div class="mini-thumb">▶</div>
      <span class="v-title">${escapeHtml(video.title)}</span>
      <span class="v-index">${String(video.index).padStart(2, "0")}</span>`;
    item.addEventListener("click", () => playVideo(video, item));
    container.appendChild(item);
  });
}

function playVideo(video, itemEl) {
  const player = document.getElementById("player");
  const overlay = document.getElementById("no-video-overlay");

  player.src = convertFileSrc(video.filePath);
  player.play().catch(() => {});
  overlay.style.display = "none";

  document.querySelectorAll(".video-item").forEach((el) => el.classList.remove("playing"));
  if (itemEl) itemEl.classList.add("playing");
}

// ───────────── ACCIONES DE SECCIÓN ─────────────
async function openAnalysisDir(section) {
  const dirMap = {
    diagnostico: state.config?.paths?.analisis,
  };
  const dir = dirMap[section.id];
  if (!dir) {
    showError("Directorio de análisis no configurado.");
    return;
  }
  try {
    await invoke("open_first_executable", { dir });
  } catch (e) {
    showError(e);
  }
}

// ───────────── BOTONES GLOBALES ─────────────
// Feedback de carga: deshabilita el botón y muestra un spinner mientras la
// acción asíncrona (invoke) está en curso. Evita clicks dobles y transmite
// "el sistema está trabajando".
function withLoading(btn, action) {
  return async () => {
    if (btn.disabled) return;
    btn.disabled = true;
    btn.classList.add("loading");
    try {
      await action();
    } finally {
      btn.disabled = false;
      btn.classList.remove("loading");
    }
  };
}

function initButtons() {
  document.getElementById("btn-minimize").addEventListener("click", () =>
    window.__TAURI__.window.getCurrentWindow().minimize()
  );

  let isFullscreen = false;
  document.getElementById("btn-fullscreen").addEventListener("click", async () => {
    const win = window.__TAURI__.window.getCurrentWindow();
    if (!isFullscreen) {
      await win.maximize();
      isFullscreen = true;
    } else {
      await win.unmaximize();
      isFullscreen = false;
    }
  });

  document.getElementById("btn-close").addEventListener("click", () =>
    window.__TAURI__.window.getCurrentWindow().close()
  );

  document.getElementById("btn-contact-support").addEventListener(
    "click",
    withLoading(document.getElementById("btn-contact-support"), () =>
      invoke("open_url", { url: "https://www.xtremediesel.com/support", embedded: false }).catch(showError)
    ),
  );

  document.getElementById("btn-open-browser").addEventListener(
    "click",
    withLoading(document.getElementById("btn-open-browser"), async () => {
      const section = window.__currentGenericSection;
      if (section?.url) {
        await invoke("open_url", { url: section.url, embedded: false }).catch(showError);
      }
    }),
  );

  document.getElementById("btn-open-embedded").addEventListener(
    "click",
    withLoading(document.getElementById("btn-open-embedded"), async () => {
      const section = window.__currentGenericSection;
      if (section?.url) {
        await invoke("open_url", { url: section.url, embedded: true }).catch(showError);
      }
    }),
  );

  document.getElementById("btn-go-videos").addEventListener("click", goVideos);
  document.getElementById("btn-open-video-folder").addEventListener(
    "click",
    withLoading(document.getElementById("btn-open-video-folder"), () =>
      // Abre en el Explorador la carpeta Videos/Tutoriales (backend real,
      // antigua versión abría la raíz del disco con file:///).
      invoke("open_videos_folder").catch(showError)
    ),
  );

  // Botón "Volver" de la vista de error: regresa al dashboard.
  document.getElementById("btn-back-error").addEventListener("click", goDashboard);
}

// ───────────── BOOT / ARRANQUE ─────────────
// Momento "impactante": el logo aparece con el nombre de la marca y una barra
// de progreso, luego el overlay se desvanece revelando el dashboard.
// Solo se muestra UNA vez por sesión (sessionStorage), no bloquea la UI
// (pointer-events: none al desvanecerse).
function runBoot() {
  const boot = document.getElementById("boot");
  if (!boot) return;
  if (sessionStorage.getItem("booted")) {
    boot.remove();
    return;
  }
  sessionStorage.setItem("booted", "1");

  const fill = boot.querySelector(".boot-bar-fill");
  requestAnimationFrame(() => {
    requestAnimationFrame(() => {
      fill.style.transition = "width 1.05s cubic-bezier(0.4, 0, 0.2, 1)";
      fill.style.width = "100%";
    });
  });

  setTimeout(() => {
    boot.classList.add("done"); // fade out (pointer-events: none)
    setTimeout(() => boot.remove(), 500);
  }, 1250);
}

// ───────────── RELOJ DEL HEADER ─────────────
// El elemento #update-time quedó muerto (siempre "--/--/----"). Un reloj vivo
// hace que el sistema se sienta operativo y en tiempo real.
function startClock() {
  const el = document.getElementById("update-time");
  const pad = (n) => String(n).padStart(2, "0");
  const update = () => {
    const d = new Date();
    el.textContent =
      `${pad(d.getDate())}/${pad(d.getMonth() + 1)}/${d.getFullYear()} ` +
      `${pad(d.getHours())}:${pad(d.getMinutes())}:${pad(d.getSeconds())}`;
  };
  update();
  setInterval(update, 1000);
}

// ───────────── ARRANQUE ─────────────
let contentChecked = false;
let binaryChecked = false;

async function checkRemoteContent() {
  if (contentChecked) return;
  contentChecked = true;
  try {
    const updated = await invoke("check_content_update");
    if (updated) {
      // Nueva versión de UI descargada: recargar desde la copia local actualizada.
      window.location.reload();
      return true;
    }
  } catch (e) {
    console.error("No se pudo verificar actualización de contenido:", e);
  }
  return false;
}

// Actualización binaria automática y silenciosa (sin interacción del usuario).
// Se ejecuta solo si `binaryEnabled` es true en el config y hay versión nueva.
const BINARY_CHECK_INTERVAL_MS = 6 * 60 * 60 * 1000; // 6 horas
async function checkRemoteBinary() {
  if (binaryChecked) return;
  binaryChecked = true;
  try {
    const enabled = state.config?.update?.binaryEnabled !== false;
    if (!enabled) return;

    const info = await invoke("check_binary_update");
    if (info?.available) {
      await invoke("apply_binary_update");
      // apply_binary_update devuelve true tras instalar; la app se reinicia
      // automáticamente con el instalador en modo silencioso (quiet).
    }
  } catch (e) {
    console.error("No se pudo verificar actualización binaria:", e);
  }
}

// Rechequeo periódico: si una versión nueva se publica con la app en marcha,
// se detecta e instala sin necesidad de reiniciar manualmente la app.
setInterval(() => {
  if (!document.hidden) {
    binaryChecked = false;
    checkRemoteBinary();
  }
}, BINARY_CHECK_INTERVAL_MS);

async function init() {
  runBoot();

  try {
    state.config = await invoke("get_config");
  } catch (e) {
    console.error("No se pudo cargar configuración", e);
    return;
  }

  renderMenu();
  renderThemeButtons();
  initButtons();
  startClock();

  // Verificación de contenido en segundo plano, no bloqueante.
  checkRemoteContent().then((updated) => {
    if (!updated) goDashboard();
  });

  // Actualización binaria también en segundo plano (tras el contenido).
  checkRemoteBinary();
}

window.addEventListener("DOMContentLoaded", init);

// ───────────── MODOS DE ACTIVIDAD ─────────────
// Registra actividad del usuario (clicks/teclado) para el modo inactividad
// del backend, con throttling para no saturar el bridge IPC.
let activityTimer = null;
function registerActivity() {
  if (activityTimer) return;
  activityTimer = setTimeout(() => {
    activityTimer = null;
    invoke("notify_activity").catch(() => {});
  }, 1000);
}
["pointerdown", "keydown", "mousemove", "wheel"].forEach((evt) =>
  window.addEventListener(evt, registerActivity, { passive: true }),
);

// ───────────── UTILIDADES ─────────────
function escapeHtml(str) {
  const div = document.createElement("div");
  div.textContent = str ?? "";
  return div.innerHTML;
}
