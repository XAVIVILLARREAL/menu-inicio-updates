const { invoke } = window.__TAURI__.core;
const { convertFileSrc } = window.__TAURI__.core;

const state = {
  config: null,
  connectionId: "",
  videos: [],
  currentSection: null,
  lastView: "dashboard",
};

// ───────────── NAVEGACIÓN DE VISTAS ─────────────
const VIEWS = ["dashboard", "support", "generic", "videos", "error", "equipment", "pcloud", "ads"];

function showView(name) {
  VIEWS.forEach((v) => {
    document.getElementById(`view-${v}`).classList.toggle("active", v === name);
  });
}

// ───────────── HISTORIAL DE NAVEGACIÓN (botón atrás) ─────────────
const viewHistory = [];

function currentView() {
  return (
    VIEWS.find((v) => document.getElementById(`view-${v}`).classList.contains("active")) ||
    "dashboard"
  );
}

function updateBack() {
  const back = document.getElementById("btn-back");
  back.style.display = currentView() === "dashboard" ? "none" : "";
}

// Navega a una vista guardando la actual en el historial.
function navTo(name) {
  const cur = currentView();
  if (cur !== name) viewHistory.push(cur);
  showView(name);
  updateBack();
}

// Volver: restaura la vista anterior (o el home si el historial está vacío).
function goBack() {
  const prev = viewHistory.pop();
  if (prev) {
    showView(prev);
  } else {
    showView("dashboard");
    refreshDashboard();
  }
  updateBack();
}

// Home explícito (logo del header): limpia el historial.
async function goHome() {
  viewHistory.length = 0;
  showView("dashboard");
  updateBack();
  await refreshDashboard();
}

async function goDashboard() {
  await goHome();
}

async function goSupport() {
  navTo("support");
  try {
    const info = await invoke("get_system_info");
    document.getElementById("support-info").textContent =
      `ID de Conexión: ${info.connectionId}\n` +
      `Equipo: ${info.computerName}\n` +
      `Usuario: ${info.userName}\n` +
      `Sistema: ${info.osVersion}`;
  } catch (e) {
    document.getElementById("support-info").textContent = `Error: ${e}`;
  }
}

function goGeneric(section) {
  navTo("generic");
  document.getElementById("generic-icon").textContent = section.icon;
  document.getElementById("generic-title").textContent = `${section.icon} ${section.title}`;
  document.getElementById("generic-message").textContent =
    "Para ingresar a esta información es necesario conectarse a internet. No actualice ni utilice programas de diagnóstico mientras está conectado a internet. De preferencia solo para usar esa base de datos es necesario que lea el manual de uso del equipo y la garantía.";
  window.__currentGenericSection = section;
}

async function goVideos() {
  navTo("videos");
  await loadVideoList();
}

function showError(msg) {
  document.getElementById("error-message").textContent = msg;
  navTo("error");
}

// ───────────── MOSAICOS (pantalla principal) ─────────────
// Tamaños: lg = 2x2, md = 2x1, sm = 1x1 (mosaicos grandes y chicos).
const TILE_SIZES = {
  equipo: "lg",
  videos: "lg",
  publicidad: "lg",
  bases: "md",
  configs: "md",
  diagnostico: "md",
  soporte: "md",
  manuales: "sm",
  calibraciones: "sm",
  garantia: "sm",
  catalogo: "sm",
  cursos: "sm",
  chatbot: "sm",
};

function renderTiles() {
  const grid = document.getElementById("tiles-grid");
  grid.innerHTML = "";

  // Mosaico de ID de conexión remota (clic → soporte, donde se usa).
  const idTile = document.createElement("div");
  idTile.className = "tile md tile-id";
  idTile.innerHTML = `
    <span class="tile-label">ID CONEXIÓN REMOTA</span>
    <span id="connection-id" class="id-value mono">CARGANDO...</span>
    <div class="status-active"><span class="dot"></span><span id="status-text">SISTEMA ACTIVO</span></div>`;
  idTile.addEventListener("click", goSupport);
  grid.appendChild(idTile);

  state.config.sections
    .filter((s) => s.type !== "dashboard")
    .forEach((section, i) => {
      const tile = document.createElement("div");
      const size = TILE_SIZES[section.id] || "sm";
      tile.className = `tile ${size}`;
      tile.dataset.id = section.id;
      tile.style.animationDelay = `${i * 40}ms`;
      // El mosaico de Promociones muestra la primera imagen de publicidad.
      if (section.type === "ads" && state.config.ads?.[0]) {
        tile.style.backgroundImage = `url(${state.config.ads[0].image})`;
        tile.classList.add("ad-tile");
      }
      tile.innerHTML = `<span class="tile-icon">${section.icon}</span><span class="tile-label">${escapeHtml(section.title)}</span>`;
      tile.addEventListener("click", () => onSectionClick(section));
      grid.appendChild(tile);
    });
}

async function onSectionClick(section) {
  switch (section.type) {
    case "dashboard":
      await goDashboard();
      break;
    case "support":
      await goSupport();
      break;
    case "videos":
      await goVideos();
      break;
    case "dir":
      await openAnalysisDir(section);
      break;
    case "equipment":
      goEquipment(section);
      break;
    case "pcloud":
      goPcloud(section);
      break;
    case "ads":
      goAds();
      break;
    case "url":
    default:
      goGeneric(section);
      break;
  }
}

// ───────────── DASHBOARD (ID + estado) ─────────────
async function refreshDashboard() {
  try {
    const connId = await invoke("get_connection_id");
    state.connectionId = connId;
    document.getElementById("connection-id").textContent = connId;
    const internet = await invoke("check_internet");
    updateStatusDot(internet);
  } catch (e) {
    document.getElementById("connection-id").textContent = "ERROR";
  }
}

function updateStatusDot(online) {
  const dot = document.querySelector(".status-active .dot");
  const text = document.getElementById("status-text");
  dot.classList.toggle("green", online);
  dot.classList.toggle("red", !online);
  text.textContent = online ? "CONECTADO A INTERNET" : "MODO OFFLINE";
}

// ───────────── TEMAS (dropdown en el header) ─────────────
let themesOpen = false;
function toggleThemes(force) {
  const menu = document.getElementById("themes-menu");
  themesOpen = force !== undefined ? force : !themesOpen;
  menu.classList.toggle("open", themesOpen);
}

function renderThemeButtons() {
  const menu = document.getElementById("themes-menu");
  const temas = state.config?.paths?.temas || [];
  menu.innerHTML = "";
  if (!temas.length) {
    menu.innerHTML = `<span class="card-label">Sin temas</span>`;
    return;
  }
  temas.forEach((path, i) => {
    const btn = document.createElement("button");
    btn.className = "theme-btn";
    btn.textContent = `⚡ Tema ${i + 1}`;
    btn.title = path;
    btn.addEventListener("click", () => {
      toggleThemes(false);
      invoke("launch", { path }).catch(showError);
    });
    menu.appendChild(btn);
  });
}

// Cerrar el dropdown al hacer clic fuera.
document.addEventListener("click", (e) => {
  if (themesOpen && !e.target.closest("#themes-wrap")) toggleThemes(false);
});

// ───────────── VIDEOS ─────────────
async function loadVideoList() {
  state.videos = await invoke("list_videos").catch(() => []);
  const container = document.getElementById("video-list");
  const count = document.getElementById("video-count");
  container.innerHTML = "";

  count.textContent = `${state.videos.length} VIDEOS`;

  if (state.videos.length === 0) {
    container.innerHTML = `<p class="card-label">No se encontraron videos. Agrega videos a la carpeta 'Videos/Tutoriales' junto al ejecutable.</p>`;
    return;
  }

  state.videos.forEach((video) => {
    const item = document.createElement("div");
    item.className = "video-item";
    item.dataset.path = video.filePath;
    item.innerHTML = `
      <div class="mini-thumb">▶</div>
      <span class="v-title">${escapeHtml(video.title)}</span>
      <span class="v-index">${String(video.index).padStart(2, "0")}</span>`;
    item.addEventListener("click", () => playVideo(video, item));
    container.appendChild(item);
  });
}

function playVideo(video, itemEl) {
  const player = document.getElementById("player");
  const overlay = document.getElementById("no-video-overlay");

  // Los videos de pCloud llegan como URL https directa; los locales usan convertFileSrc.
  player.src = /^https?:\/\//.test(video.filePath || video.path || "")
    ? video.filePath
    : convertFileSrc(video.filePath);
  player.play().catch(() => {});
  overlay.style.display = "none";

  document.querySelectorAll(".video-item").forEach((el) => el.classList.remove("playing"));
  if (itemEl) itemEl.classList.add("playing");
}

// ───────────── ACCIONES DE SECCIÓN ─────────────
async function openAnalysisDir(section) {
  const dirMap = {
    diagnostico: state.config?.paths?.analisis,
  };
  const dir = dirMap[section.id];
  if (!dir) {
    showError("Directorio de análisis no configurado.");
    return;
  }
  try {
    await invoke("open_first_executable", { dir });
  } catch (e) {
    showError(e);
  }
}

// ───────────── HUB: MI EQUIPO / pCLOUD / PUBLICIDAD ─────────────
let pcloudStack = [];

function goEquipment(section) {
  navTo("equipment");
  const eq = state.config?.equipment || {};
  document.getElementById("equipment-subtitle").textContent = eq.subtitle || section.title;
  const list = document.getElementById("equipment-specs");
  list.innerHTML = "";
  (eq.specs || []).forEach((spec) => {
    const li = document.createElement("li");
    li.textContent = `✓ ${spec}`;
    list.appendChild(li);
  });
  const docsBtn = document.getElementById("btn-equipment-docs");
  if (eq.docsPath) {
    docsBtn.style.display = "";
    docsBtn.onclick = () => goPcloud({ id: "equipo", title: "Documentos del Equipo", path: eq.docsPath });
  } else {
    docsBtn.style.display = "none";
  }
}

function goPcloud(section) {
  navTo("pcloud");
  document.getElementById("pcloud-title").textContent = (section.title || "BASES DE DATOS").toUpperCase();
  document.getElementById("pcloud-player-wrap").style.display = "none";
  pcloudStack = [];
  loadPcloud(section.path || "/");
}

function pcloudIconFor(name) {
  const ext = (name.split(".").pop() || "").toLowerCase();
  if (["mp4", "avi", "mkv", "wmv", "webm"].includes(ext)) return "🎬";
  if (ext === "pdf") return "📄";
  if (["jpg", "jpeg", "png", "gif", "bmp"].includes(ext)) return "🖼️";
  if (["zip", "rar", "7z"].includes(ext)) return "🗜️";
  return "📄";
}

async function loadPcloud(path) {
  const grid = document.getElementById("pcloud-grid");
  document.getElementById("pcloud-path").textContent = path;
  grid.innerHTML = `<p class="card-label">Cargando desde pCloud…</p>`;
  try {
    const items = await invoke("pcloud_list", { dir: path });
    if (!items.length) {
      grid.innerHTML = `<p class="card-label">Carpeta vacía</p>`;
      return;
    }
    grid.innerHTML = "";
    items.forEach((item) => {
      const el = document.createElement("div");
      el.className = `pcloud-item ${item.isFolder ? "folder" : "file"}`;
      el.innerHTML = `<span class="pcloud-icon">${item.isFolder ? "📁" : pcloudIconFor(item.name)}</span><span class="pcloud-name">${escapeHtml(item.name)}</span>`;
      el.addEventListener("click", () => onPcloudItem(item));
      grid.appendChild(el);
    });
  } catch (e) {
    grid.innerHTML = `<p class="card-label">${escapeHtml(String(e))}</p>`;
  }
}

function onPcloudItem(item) {
  if (item.isFolder) {
    pcloudStack.push(item.path);
    loadPcloud(item.path);
    return;
  }
  const ext = (item.name.split(".").pop() || "").toLowerCase();
  if (["mp4", "avi", "mkv", "wmv", "webm"].includes(ext)) {
    playPcloudVideo(item, document.getElementById("pcloud-player"), "pcloud-player-wrap");
  } else {
    invoke("pcloud_open", { path: item.path }).catch(showError);
  }
}

async function playPcloudVideo(item, player, wrapId) {
  try {
    const url = await invoke("pcloud_file_url", { path: item.path || item.filePath });
    if (wrapId) document.getElementById(wrapId).style.display = "block";
    player.src = url;
    player.play().catch(() => {});
  } catch (e) {
    showError(e);
  }
}

// ───────────── PUBLICIDAD ─────────────
let adsIndex = 0;
let adsTimer = null;

function showAdsSlide(i) {
  const slides = document.querySelectorAll(".ads-slide");
  const dots = document.querySelectorAll(".ads-dot");
  if (!slides.length) return;
  adsIndex = (i + slides.length) % slides.length;
  slides.forEach((s, j) => s.classList.toggle("active", j === adsIndex));
  dots.forEach((d, j) => d.classList.toggle("active", j === adsIndex));
}

function startAdsAuto() {
  if (adsTimer) clearInterval(adsTimer);
  adsTimer = setInterval(() => showAdsSlide(adsIndex + 1), 6000);
}

function renderAdsCarousel() {
  const ads = state.config?.ads || [];
  const track = document.getElementById("ads-track");
  const dots = document.getElementById("ads-dots");
  track.innerHTML = "";
  dots.innerHTML = "";
  if (!ads.length) {
    track.innerHTML = `<p class="card-label">Sin promociones configuradas</p>`;
    return;
  }
  ads.forEach((ad, i) => {
    const slide = document.createElement("div");
    slide.className = `ads-slide${i === 0 ? " active" : ""}`;
    slide.innerHTML = `<img src="${ad.image}" alt="${escapeHtml(ad.title || "")}" draggable="false"/>`;
    if (ad.url) {
      slide.addEventListener("click", () => invoke("open_url", { url: ad.url, embedded: false }).catch(showError));
    }
    track.appendChild(slide);
    const dot = document.createElement("span");
    dot.className = `ads-dot${i === 0 ? " active" : ""}`;
    dot.addEventListener("click", () => showAdsSlide(i));
    dots.appendChild(dot);
  });
  adsIndex = 0;
  startAdsAuto();
}

function goAds() {
  navTo("ads");
  renderAdsCarousel();
}

// ───────────── BOTONES GLOBALES ─────────────
// Feedback de carga: deshabilita el botón y muestra un spinner mientras la
// acción asíncrona (invoke) está en curso.
function withLoading(btn, action) {
  return async () => {
    if (btn.disabled) return;
    btn.disabled = true;
    btn.classList.add("loading");
    try {
      await action();
    } finally {
      btn.disabled = false;
      btn.classList.remove("loading");
    }
  };
}

function initButtons() {
  document.getElementById("btn-home").addEventListener("click", goHome);
  document.getElementById("btn-back").addEventListener("click", goBack);

  document.getElementById("btn-themes").addEventListener("click", () => toggleThemes());

  document.getElementById("btn-minimize").addEventListener("click", () =>
    window.__TAURI__.window.getCurrentWindow().minimize()
  );

  let isFullscreen = false;
  document.getElementById("btn-fullscreen").addEventListener("click", async () => {
    const win = window.__TAURI__.window.getCurrentWindow();
    if (!isFullscreen) {
      await win.maximize();
      isFullscreen = true;
    } else {
      await win.unmaximize();
      isFullscreen = false;
    }
  });

  document.getElementById("btn-close").addEventListener("click", () =>
    window.__TAURI__.window.getCurrentWindow().close()
  );

  document.getElementById("btn-contact-support").addEventListener(
    "click",
    withLoading(document.getElementById("btn-contact-support"), () =>
      invoke("open_url", { url: "https://www.xtremediesel.com/support", embedded: false }).catch(showError)
    ),
  );

  document.getElementById("btn-open-browser").addEventListener(
    "click",
    withLoading(document.getElementById("btn-open-browser"), async () => {
      const section = window.__currentGenericSection;
      if (section?.url) {
        await invoke("open_url", { url: section.url, embedded: false }).catch(showError);
      }
    }),
  );

  document.getElementById("btn-open-embedded").addEventListener(
    "click",
    withLoading(document.getElementById("btn-open-embedded"), async () => {
      const section = window.__currentGenericSection;
      if (section?.url) {
        await invoke("open_url", { url: section.url, embedded: true }).catch(showError);
      }
    }),
  );

  document.getElementById("btn-open-video-folder").addEventListener(
    "click",
    withLoading(document.getElementById("btn-open-video-folder"), () =>
      invoke("open_videos_folder").catch(showError)
    ),
  );

  // Botón "Volver" de la vista de error: regresa al dashboard.
  document.getElementById("btn-back-error").addEventListener("click", goDashboard);

  // Hub: subir de nivel en el browser pCloud y cerrar el reproductor.
  document.getElementById("btn-pcloud-up").addEventListener("click", () => {
    const prev = pcloudStack.pop();
    if (prev) loadPcloud(prev);
  });
  document.getElementById("btn-pcloud-close-player").addEventListener("click", () => {
    document.getElementById("pcloud-player-wrap").style.display = "none";
    document.getElementById("pcloud-player").pause();
  });

  // Publicidad: navegación del carrusel.
  document.getElementById("ads-prev").addEventListener("click", () => showAdsSlide(adsIndex - 1));
  document.getElementById("ads-next").addEventListener("click", () => showAdsSlide(adsIndex + 1));

  // Videos: catálogo desde pCloud dentro de la vista de videos.
  document.getElementById("btn-pcloud-videos").addEventListener("click", async () => {
    const path = state.config?.pcloud?.videosPath || "/MenuInicio/Videos";
    const container = document.getElementById("pcloud-video-list");
    container.innerHTML = `<p class="card-label">Cargando desde pCloud…</p>`;
    try {
      const items = await invoke("pcloud_list", { dir: path });
      const videos = items.filter((i) => !i.isFolder && /\.(mp4|avi|mkv|wmv|webm)$/i.test(i.name));
      if (!videos.length) {
        container.innerHTML = `<p class="card-label">Sin videos en pCloud (${escapeHtml(path)})</p>`;
        return;
      }
      container.innerHTML = "";
      videos.forEach((v) => {
        const item = document.createElement("div");
        item.className = "video-item";
        item.innerHTML = `<div class="mini-thumb">▶</div><span class="v-title">${escapeHtml(v.name)}</span>`;
        item.addEventListener("click", () => playPcloudVideo(v, document.getElementById("player"), null));
        container.appendChild(item);
      });
    } catch (e) {
      container.innerHTML = `<p class="card-label">${escapeHtml(String(e))}</p>`;
    }
  });
}

// ───────────── BOOT / ARRANQUE ─────────────
function runBoot() {
  const boot = document.getElementById("boot");
  if (!boot) return;
  if (sessionStorage.getItem("booted")) {
    boot.remove();
    return;
  }
  sessionStorage.setItem("booted", "1");

  const fill = boot.querySelector(".boot-bar-fill");
  requestAnimationFrame(() => {
    requestAnimationFrame(() => {
      fill.style.transition = "width 1.05s cubic-bezier(0.4, 0, 0.2, 1)";
      fill.style.width = "100%";
    });
  });

  setTimeout(() => {
    boot.classList.add("done");
    setTimeout(() => boot.remove(), 500);
  }, 1250);
}

// ───────────── RELOJ DEL HEADER ─────────────
function startClock() {
  const el = document.getElementById("update-time");
  const pad = (n) => String(n).padStart(2, "0");
  const update = () => {
    const d = new Date();
    el.textContent =
      `${pad(d.getDate())}/${pad(d.getMonth() + 1)}/${d.getFullYear()} ` +
      `${pad(d.getHours())}:${pad(d.getMinutes())}:${pad(d.getSeconds())}`;
  };
  update();
  setInterval(update, 1000);
}

// ───────────── ARRANQUE ─────────────
let contentChecked = false;
let binaryChecked = false;

async function checkRemoteContent() {
  if (contentChecked) return;
  contentChecked = true;
  try {
    const updated = await invoke("check_content_update");
    if (updated) {
      window.location.reload();
      return true;
    }
  } catch (e) {
    console.error("No se pudo verificar actualización de contenido:", e);
  }
  return false;
}

const BINARY_CHECK_INTERVAL_MS = 6 * 60 * 60 * 1000; // 6 horas
async function checkRemoteBinary() {
  if (binaryChecked) return;
  binaryChecked = true;
  try {
    const enabled = state.config?.update?.binaryEnabled !== false;
    if (!enabled) return;

    const info = await invoke("check_binary_update");
    if (info?.available) {
      await invoke("apply_binary_update");
    }
  } catch (e) {
    console.error("No se pudo verificar actualización binaria:", e);
  }
}

setInterval(() => {
  if (!document.hidden) {
    binaryChecked = false;
    checkRemoteBinary();
  }
}, BINARY_CHECK_INTERVAL_MS);

async function init() {
  runBoot();

  try {
    state.config = await invoke("get_config");
  } catch (e) {
    console.error("No se pudo cargar configuración", e);
    return;
  }

  renderTiles();
  renderThemeButtons();
  initButtons();
  startClock();

  checkRemoteContent().then((updated) => {
    if (!updated) goDashboard();
  });

  checkRemoteBinary();
}

window.addEventListener("DOMContentLoaded", init);

// ───────────── MODOS DE ACTIVIDAD ─────────────
let activityTimer = null;
function registerActivity() {
  if (activityTimer) return;
  activityTimer = setTimeout(() => {
    activityTimer = null;
    invoke("notify_activity").catch(() => {});
  }, 1000);
}
["pointerdown", "keydown", "mousemove", "wheel"].forEach((evt) =>
  window.addEventListener(evt, registerActivity, { passive: true }),
);

// ───────────── UTILIDADES ─────────────
function escapeHtml(str) {
  const div = document.createElement("div");
  div.textContent = str ?? "";
  return div.innerHTML;
}
